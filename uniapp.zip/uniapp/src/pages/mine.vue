<template>
	<view class="mine">
	  <view class="top">
	    <image :src="CurrentUser.avatar" @click="changeAvatar" class="avatar"></image>
		<view class="name">{{ CurrentUser.name }}</view>
	  </view>
	  
	  <view class="bottom">
		<view class="lable">
			<view>邮箱: {{ CurrentUser.email }}</view>
			<view>性别: {{ CurrentUser.gender }}</view>
			<view>生日: {{ CurrentUser.birthday || '未设置' }}</view>
			<view>个人介绍:</view>
			<view class="sub">{{ CurrentUser.bio|| '未设置' }}</view>
	    </view>
		<view class="button">
			<button class="gray" @click="editProfile">编辑资料</button>
			<button class="red" @click="logout">注销</button>
		</view>
	  </view>
    </view>
</template>

<script>
export default {
  data() {
    return {
      CurrentUser: uni.getStorageSync('currentUser') || {},
    };
  },
  onLoad() {
    // 确保在页面加载时，currentUser 已经是最新的
    this.loadCurrentUser();
  },
  methods: {
    loadCurrentUser() {
     const storedUser = uni.getStorageSync('currentUser');
       if (storedUser) {
         // 使用解构赋值来确保只覆盖存在的属性
        this.CurrentUser = { 
          ...this.CurrentUser,
           ...storedUser,
        };
        console.log('Current user loaded from local storage:', this.CurrentUser);
      } else {
        console.warn('No user information found in local storage.');
      }
    },
	async changeAvatar() {
	  try {
		// 使用 Promise 来包裹 chooseImage 以便使用 async/await
		const res = await new Promise((resolve, reject) => {
		  uni.chooseImage({
			count: 1,  // 最多选择一张图片
			sizeType: ['compressed', 'original'],  // 只选择压缩后的图片
			sourceType: ['album', 'camera'],  // 可从相册或相机选择
			success: (res) => resolve(res),  // 成功时返回结果
			fail: (err) => reject(err)  // 失败时抛出错误
		  });
		});

		// 打印返回的完整结果，帮助调试
		console.log("chooseImage result:", res);

		// 检查返回值结构，确认 tempFilePaths 是否有效
		if (res && res.tempFilePaths && res.tempFilePaths.length > 0) {
		  const tempFilePath = res.tempFilePaths[0];  // 获取选中的图片路径

		  // 上传头像
		  const uploadResult = await this.uploadAvatar(tempFilePath);

		  // 如果上传成功，更新用户头像
		  if (uploadResult) {
			this.CurrentUser.avatar = uploadResult;
			uni.setStorageSync('currentUser', this.CurrentUser);
			console.log('Avatar updated successfully:', this.CurrentUser);
			uni.showToast({ title: '头像更新成功', icon: 'success' });
		  } else {
			// 上传失败提示
			console.error('Failed to get uploaded image URL.');
			uni.showToast({ title: '头像上传失败，请重试', icon: 'none' });
		  }
		} else {
		  // 如果 tempFilePaths 为空，打印详细的错误信息
		  console.error('No image selected or invalid response:', res);
		  uni.showToast({ title: '未选择图片或返回结果异常', icon: 'none' });
		}
	  } catch (err) {
		// 捕获选择图片或上传时的错误
		console.error('Failed to choose or upload image:', err);
		uni.showToast({ title: '选择或上传头像时出错', icon: 'none' });
	  }
	},

	// 上传头像
	async uploadAvatar(tempFilePath) {
	  const token = uni.getStorageSync('Authorization')
	  if (!token) {
	    uni.showToast({ title: '未登录，请先登录', icon: 'none' });
	    return null;
	  }
	
	  try {
	    return new Promise((resolve, reject) => {
	      uni.uploadFile({
	        url: 'http://120.46.94.52:5200/api/v1/upload/images',  // 上传图片的服务器地址
	        filePath: tempFilePath,  // 使用选择的图片路径
	        name: 'file',  // 文件字段名，根据服务器接口要求调整
	        header: {
	          Authorization: uni.getStorageSync('Authorization')
	        },
	        success: (res) => {
	          console.log("Upload response:", res);  // 打印完整的响应
	
	          const responseData = JSON.parse(res.data);
	          if (responseData.code === 200 && responseData.data && responseData.data.img_url) {
	            console.log('Image URL:', responseData.data.img_url);
	            resolve(responseData.data.img_url);  // 解析并返回图片的 URL
	          } else {
	            console.error('Upload failed:', responseData.msg);
	            uni.showToast({ title: '头像上传失败，请稍后再试', icon: 'none' });
	            reject(null);  // 上传失败，返回 null
	          }
	        },
	        fail: (err) => {
	          console.error('Upload error:', err);
	          uni.showToast({ title: '头像上传时发生错误', icon: 'none' });
	          reject(null);  // 上传失败，返回 null
	        }
	      });
	    });
	  } catch (error) {
	    console.error('Upload error:', error);
	    uni.showToast({ title: '头像上传时发生错误', icon: 'none' });
	    return null;
	  }
	},


	logout() {
      // 清除本地存储中的用户信息并跳转到登录页面
      uni.removeStorageSync('currentUser');
      uni.removeStorageSync('Authorization'); // 同时清除token
      uni.reLaunch({ url: '/pages/login' }); 
    },

    editProfile() {
      // 跳转到编辑资料页面
      uni.navigateTo({ url: '/pages/edit-profile' });
    }
  }
};
</script>

<style scoped>
	.mine {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.top {
		height: 30%;
	  	width: 100%;
		background-color: #e6e6e6;
	  	display: flex;
		position: relative;
	  	flex-direction: column;
	  	justify-content: center;
	  	align-items: center;
	  
	}
	.top .name {
		margin-top: 20rpx;
		padding:10rpx;
		font-size: 15px;
		font-weight: bold;
		border-radius: 10rpx;
	}
	.avatar {
		width: 156rpx;
	  	height: 156rpx;
	  	border-radius: 156rpx;
	  /* box-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.1); */
	}
	
	.lable {
		height: 70%;
	  	margin: 10%;
	  	display: block; /* 确保.subtitle表现为块级元素 */
	}
	
	.lable view {
	  display: block; /* 使每个.text元素占据一行 */
	  line-height: 1.5;
	}
	.sub{
		max-height: 60%;
		padding: 5%;
		overflow: hidden;  /* 隐藏溢出的水平内容 */
		overflow-y: auto; /* 当内容超出时显示垂直滚动条 */
		border-radius: 20rpx;
		border: 5rpx solid #e6e6e6;
	}

	.bottom {
		display: flex;
		flex-direction: column;
		line-height: 50rpx;
	}
	.button {
	  width: 100%;
	  text-align: center;
	  display: flex; /* 使用flex布局 */
	  justify-content: space-around;
	  position: absolute;
	  bottom: 5%;
	}
	.button button{
	  width: 40%;
	  height: 76rpx;
	  line-height: 76rpx;
	  margin: 20rpx;
	  border-radius: 10rpx;
	  font-size: 34rpx;
	}
	.red{
	  background-color: #d02129;
	  color: #FFFFFF;
	}
	.gray{
	  background-color: #e6e6e6;
	  color: #000000;
	}

</style>
