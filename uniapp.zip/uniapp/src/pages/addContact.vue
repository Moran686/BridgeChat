<template>
	<div>
		<view class="add-friend-page">
			<view class="search-input-box">
			  <input v-model="searchQuery" class="search-input" placeholder="输入..."/>
			  <button class="search-button" @click="searchID">搜索</button>
			</view>
		</view>
		<scroll-view scroll-y="true">
			<div class="contacts">
			  <div class="contacts-container">
				<div class="user-list" v-if="searchPerformed && groups.length !== 0">
					<view class="contacts-title" v-if="groups && groups.length !==0">社区</view>
				  <div class="user-list-item" v-for="(group, id) in groups" :key="id" @click="groupDetail(group)">
					<div class="user-item-avatar">
					  <image :src="group.avatar"/>
					</div>
					<div class="user-item-info">
					  <span class="user-item-info__name">{{ group.name }}</span>
					</div>
				  </div>
				  <view class="contacts-title" v-if="friends && friends.length !==0">用户</view>
				  <div class="user-list-item" v-for="(friend, id) in friends" :key="id" @click="friendDetail(friend)">
					<div class="user-item-avatar">
					  <image :src="friend.avatar"></image>
					</div>
					<div class="user-item-info">
					  <span class="user-item-info__name">{{ friend.name }}</span>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		</scroll-view>
		<view v-show="errorVisible" class="alert-box">
		  <view>{{ errorText }}</view>
		</view>
	</div>	
</template>

<script>
	import restApi from '../lib/restapi';
	
	export default {
	  name: 'addContact',
	  data() {
	    return {
	      searchQuery: '', // 绑定到输入框的数据
		  friends: [],
		  groups: [],
		  searchPerformed: false,
		  errorVisible: false,
		  errorText: '',
	    };
	  },
	  onShow() {
	    let currentUser = getApp().globalData.currentUser;
	  },
	  methods: {
	    async searchID(id) {
	      // 搜索好友的逻辑
	      // 这里可以调用API获取搜索结果，并更新页面数据
		  this.searchPerformed = true;
		  try {
		    const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/roomListPublic', {
		      method: 'GET',
		      headers: {
		        'Content-Type': 'application/json'
		      },
		    });
		    
		    const result = await response.json();
		    console.log(result);
		    if (result.code === 200) { // 假设后端返回code为200时表示登录成功
		       this.groups=result.data;
		    } else {
		      // 将后端返回的错误信息设置到 errorText 中
		      this.errorVisible = true;
		      this.errorText = result.msg;
		      throw new Error(this.errorText);
		    }
		  } catch (error) {
		    this.errorVisible = true;
		    this.errorText = error.message;
		    // 可以在这里添加更多的错误处理逻辑
		  }
	    },
		groupDetail(group){
			console.log(group.id);
			uni.navigateTo({
			  url: './group?to=' + group.id
			});
		},
		friendDetail(friend){
			console.log(friend.id);
			uni.navigateTo({
			  url: './friend?to=' + friend.id
			});
		},
	  },
	};
</script>

<style>
	.add-friend-page {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  padding: 20px;
	}
	
	.search-input-box {
	  display: flex;
	  margin-bottom: 10px;
	}
	
	.search-input {
	  width: 480rpx;
	  height: 70rpx;
	  flex-grow: 1;
	  padding-left: 10px;
	  border: 1px solid #ccc;
	  border-radius: 4px;
	  outline: none;
	}
	
	.search-button {
	  width: 150rpx;
	  height: 70rpx;
	  margin-left: 10px;
	  border: none;
	  border-radius: 4px;
	  cursor: pointer;
	  color: #ffffff;
	  background: #d02129;
	  line-height: 70rpx;
	  font-size: 30rpx;
	  text-align: center;
	}
	
	.search-button:hover {
	  background-color: #b0302e;
	}
	
	.contacts {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	
	.contacts .contacts-container {
	  width: 100%;
	  height: 100%;
	  overflow: auto;
	}
	
	.contacts .user-list-item {
	  height: 132rpx;
	  padding-left: 32rpx;
	  display: flex;
	  align-items: center;
	}
	
	.contacts .contacts-title {
	  height: 80rpx;
	  line-height: 100rpx;
	  font-size: 34rpx;
	  color: #666666;
	  background: #F3F4F7;
	  text-indent: 44rpx;
	}
	
	.contacts .user-list {
	  flex-grow: 1;
	  background: #ffffff;
	  display: flex;
	  flex-direction: column;
	}
	
	.contacts .user-item-avatar {
	  width: 96rpx;
	  height: 96rpx;
	  margin-right: 32rpx;
	  overflow: hidden;
	  position: relative;
	}
	
	.contacts .user-item-avatar image {
	  width: 100%;
	  height: 100%;
	  display: block;
	}
	
	.contacts .user-item-info {
	  height: 130rpx;
	  padding-right: 32rpx;
	  line-height: 88rpx;
	  flex-grow: 1;
	  border-bottom: 1px solid #EFEFEF;
	  display: flex;
	  justify-content: space-between;
	  align-items: center;
	}
	
	.contacts .user-item-info__name {
	  font-size: 34rpx;
	  font-family: Source Han Sans CN;
	  font-style: normal;
	  font-weight: bold;
	  color: #262628;
	}
	
	.contacts .user-item-info__tips {
	  height: 44rpx;
	  width: 64rpx;
	  border-radius: 24rpx;
	  font-size: 34rpx;
	  line-height: 44rpx;
	  background: #D02129;
	  color: #ffffff;
	  font-family: Cabin;
	  text-align: center;
	}
	
	.contacts .online-dot {
	  position: absolute;
	  width: 32rpx !important;
	  height: 32rpx !important;
	  right: 0;
	  bottom: 0;
	}
	.alert-box {
	  width: 650rpx;
	  height: 150rpx;
	  margin-bottom: 60rpx;
	  padding: 0rpx 20rpx;
	  font-size: 34rpx;
	  line-height: 48rpx;
	  display: flex;
	  align-content: center;
	  overflow: hidden;
	  color: #EE593C;
	  align-items: center;
	}
</style>