<template>
	<view class="group-member">
		<view class="member">
			<image 
			  :src="userAvatar.avatar" 
			  class="group-member__item" 
			  v-for="userAvatar in userAvatars" 
			  :key="userAvatar.id" 
			  @click="navigateToChat(userAvatar)">
			</image>
		</view>
	</view>
</template>

<script>
	export default {
		name : 'member',
		data () {
			return {
				members : [],
				userAvatars: [],
			}
		},
		onLoad (options) {
			//群成员数据
			this.members = JSON.parse(options.members);
			this.currentUser =getApp().globalData.currentUser;
			uni.setNavigationBarTitle({
				title : '成员（' + (this.members.length || 0) +'）'
			});
		},
		onShow() {
			this.fetchUserAvatars();
		},
		methods:{
			async profile(id) {
				let avatar=null;
				try {
					const response = await fetch(`http://120.46.94.52:5200/api/v1/user/profile?id=${encodeURIComponent(id)}`, {
						method: 'GET',
						headers: {
							'Content-Type': 'application/json',
							Authorization: uni.getStorageSync('Authorization')
						},
					});
					const result = await response.json();
					console.log(result);
					if (result.code === 200) { 
						avatar=result.data.avatar;
					} else {
						uni.showToast({
						  title: result.msg,
						  icon: 'none'
						});
					}
				} catch (error) {
					uni.showToast({
					  title:error.message,
					  icon: 'none'
					});
				};
			  return avatar; 
			},
			async fetchUserAvatars() {
			  // 提取所有的 userId
			  const userIds = this.members.map(member => member.userId);
			  // 创建一个数组，包含对每个 userId 的 profile 调用的 Promise
			  const avatarPromises = userIds.map(userId => this.profile(userId));
			
			  try {
			    // 使用 Promise.all 等待所有 Promise 的完成
			    const avatars = await Promise.all(avatarPromises);
			    // 构建最终的 userAvatars 数组，包含 id 和 avatar
			    this.userAvatars = avatars.map((avatar, index) => ({
			      id: userIds[index], // 使用原始的 userIds 数组来获取正确的 id
			      avatar: avatar // 这里的 avatar 是从 profile 函数获取的
			    }));
			    console.log('群成员:',this.userAvatars); // 输出最终的 userAvatars 数组
			  } catch (error) {
			    console.error("Error fetching user avatars:", error);
			  }
			},
			navigateToChat(userAvatar) {
			    if (this.currentUser.id === userAvatar.id) {
			      uni.switchTab({ url: './mine' });
			    } else {
			      uni.navigateTo({
			        url: `./friend?to=${userAvatar.id}`
			      });
			    }
			},
		},
	}
</script>

<style>
	.member{
		padding: 20rpx;
	}
	.group-member__item{
		width: 96rpx;
		height: 96rpx;
		border-radius: 48rpx;
		margin-right: 20rpx;
		margin-bottom: 20rpx;
	}
</style>
