<template>
	<div class="group">
	  <div class="before":style="{ backgroundImage: 'url(' + group.bgImage + ')'}"></div>
	  <div class="top">
		
	    <image :src="group.avatar" class="image-avatar"></image>
	    <view class="name">{{ group.name }}</view>
	  </div>
	  
	  <div class="bottom">
	    <view class="subtitle">
			<view>社区ID：{{group.id}}</view>
			<view>介绍：</view>
			<view class="sub">{{group.bio}}</view>
		</view>
		<!-- 错误提示信息-->
		<view v-show="errorVisible" class="alert-box">
			<span>{{ errorText }}</span>
		</view>
	    <view class="subscribe">
	        <button class="gray" v-if="identity === 0" @click="outChat">删除社区</button>
	        <button class="gray" v-if="identity === 0" @click="editGroup">编辑信息</button>
	        <button class="red" v-if="identity === 2" @click="addChat">订阅</button>
	        <button class="gray" v-if="identity === 1" @click="outChat">取消订阅</button>
			<button class="red" v-if="identity === 0 || identity === 1" @click="groupChat">发消息</button>
	    </view>
	  </div>
	</div>
</template>

<script>
	export default {
	  name: 'group',
	  data() {
	    return {
	      group: null,
		  id:0,
		  errorVisible: false,
		  errorText: '',
		  actionVisible:false,
		  identity:-1,
		  currentUserId:0,
	    }
	  },
	  onLoad(options) {
	      // options参数包含了页面跳转时传递的参数
	      const id = options.to; // 从options中读取id
		  this.id=id;
	      console.log('Group ID:', this.id);
		  this.currentUserId = getApp().globalData.currentUser.id;
		  console.log('user ID:', this.currentUserId);
		  
	  },
	  async onShow() {
		try {
			const response = await fetch(`http://120.46.94.52:5200/api/v1/chatRoom/getChatRoomsMembers?id=${encodeURIComponent(this.id)}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				},
			});
			const result = await response.json();
			console.log(result.data);
			if (result.code === 200) { 
				let userExists =result.data.some(item => item.userId === this.currentUserId);
				console.log('是否存在：',userExists);
				if (userExists) {
				  this.identity=1;
				} else {
				  this.identity=2;
				}
			} else {
				this.errorVisible = true;
				this.errorText = result.msg;
				throw new Error(this.errorText);
			}
		} catch (error) {
			this.errorVisible = true;
			this.errorText = error.message;
		};
		try {
			const response = await fetch(`http://120.46.94.52:5200/api/v1/chatRoom/getRoomById?id=${encodeURIComponent(this.id)}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				},
			});
			const result = await response.json();
			console.log(result);
			if (result.code === 200) { 
			    this.group=result.data;
				console.log('creatorId:',this.group.creatorId)
				if(this.group.creatorId===this.currentUserId){
					this.identity=0;
				}
			} else {
				this.errorVisible = true;
				this.errorText = result.msg;
				throw new Error(this.errorText);
			}
		} catch (error) {
			this.errorVisible = true;
			this.errorText = error.message;
		};
		console.log('identity:', this.identity);
	  },
	  methods: {
	    async addChat () {
		  //加入社区
		  try {
		  	const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/joinRoom', {
		  		method: 'POST',
		  		headers: {
		  			'Content-Type': 'application/json',
					Authorization: uni.getStorageSync('Authorization')
		  		},
				body: JSON.stringify({
				  id: this.id,
				}),
		  	});
		  	const result = await response.json();
		  	console.log(result);
		  	if (result.code === 200) {
				//跳转聊天
				uni.navigateTo({
					url: './groupChat?to=' + this.id
				});
		  	} else {
		  		this.errorVisible = true;
		  		this.errorText = result.msg;
		  		throw new Error(this.errorText);
		  	}
		  } catch (error) {
		  	this.errorVisible = true;
		  	this.errorText = error.message;
		  };
		  
	    },
		groupChat () {
		  uni.navigateTo({
		    url: './groupChat?to=' + this.id
		  });
		},
		editGroup(){
			uni.navigateTo({
			  url: './editGroup?group='+JSON.stringify(this.group)
			});
		},
		async outChat(){
			console.log('钥匙:',uni.getStorageSync('Authorization'));
			try {
				const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/leaveChatRoom', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						Authorization: uni.getStorageSync('Authorization')
					},
					body: JSON.stringify({
					  id: this.id,
					}),
				});
				const result = await response.json();
				console.log(result);
				if (result.code === 200) {
					uni.switchTab({ url: './contacts' });
				} else {
					this.errorVisible = true;
					this.errorText = result.msg;
					throw new Error(this.errorText);
				}
			} catch (error) {
				this.errorVisible = true;
				this.errorText = error.message;
			};
		},
		showAction(){
			this.actionVisible=true
		},
	  }
	}
</script>
	
<style>
	.group {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	.before {
	  position: absolute;
	  top: 0;
	  left: 0;
	  right: 0;
	  bottom: 70%;
	  background-size: cover;
	  opacity: 0.5; /* 设置背景图片的不透明度 */
	  background-color: #e6e6e6;
	  z-index: 0; /* 确保.before在.top之下 */
	}
	.top {
	  height: 30%;
	  width: 100%;
	  background-color: none;
	  display: flex;
	  position: relative;
	  flex-direction: column;
	  justify-content: center;
	  align-items: center;
	  z-index: 1;
	}
	
	.image-avatar {
	  width: 156rpx;
	  height: 156rpx;
	  border-radius: 156rpx;
	}
	
	.top .name {
	  margin-top: 20rpx;
	  padding:10rpx;
	  font-size: 15px;
	  font-weight: bold;
	  border-radius: 10rpx;
	}
	
	.bottom {
	  line-height: 50rpx;
	}
	
	.subtitle {
	  height: 70%;
	  margin: 10%;
	  display: block; /* 确保.subtitle表现为块级元素 */
	}
	
	.subtitle view {
	  display: block; /* 使每个.text元素占据一行 */
	  line-height: 1.5;
	}
	.sub{
		max-height: 60%;
		padding: 5%;
		overflow: hidden;  /* 隐藏溢出的水平内容 */
		overflow-y: auto; /* 当内容超出时显示垂直滚动条 */
		border-radius: 20rpx;
		border: 5rpx solid #e6e6e6;
	}
	
	.subscribe {
	  width: 100%;
	  text-align: center;
	  display: flex; /* 使用flex布局 */
	  justify-content: space-around;
	  position: absolute;
	  bottom: 5%;
	}
	.subscribe button{
	  width: 40%;
	  height: 76rpx;
	  line-height: 76rpx;
	  margin: 20rpx;
	  border-radius: 10rpx;
	  
	  font-size: 34rpx;
	}
	.red{
	  background-color: #d02129;
	  color: #FFFFFF;
	}
	.gray{
	  background-color: #e6e6e6;
	  color: #000000;
	}
	.alert-box {
	  width: 500rpx;
	  height: 150rpx;
	  margin-bottom: 60rpx;
	  padding: 0rpx 20rpx;
	  font-size: 34rpx;
	  line-height: 48rpx;
	  display: flex;
	  align-content: center;
	  overflow: hidden;
	  color: #EE593C;
	  align-items: center;
	}
</style>