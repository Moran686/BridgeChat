<template>
	<scroll-view>
		<view class="slider">
			<swiper class="sliderBox" indicator-dots autoplay circular>
				<swiper-item>
					<image class="slider-image" src="/static/images/slider-1.jpg" mode="aspectFill"></image>
				</swiper-item>
				<swiper-item>
					<image class="slider-image" src="/static/images/slider-2.jpg" mode="aspectFill"></image>
				</swiper-item>
				<swiper-item>
					<image class="slider-image" src="/static/images/slider-3.jpg" mode="aspectFill"></image>
				</swiper-item>
			</swiper>
		</view>
		<view class="table-container">
		    <raito-waterfall
		    	keyName="id"
		    	:data="newgroups" 
		    	:count="2" 
		    	:gutter="10" 
		    	:lrPading="10" 
		    	:skeletonHeight="140" 
		    	:animation="false"
		    >
		    </raito-waterfall>
			<view v-show="errorVisible" class="alert-box">
			  <view>{{ errorText }}</view>
			</view>
		</view>
	</scroll-view>
</template>

<script>
	import restApi from '../lib/restapi';
	export default {
	  name: 'square',
	  data() {
	    return {
	      groups: [],
		  newgroups:[],
		  errorVisible: false,
		  errorText: '',
	    }
	  },
	  async onShow() {
	    let currentUser = getApp().globalData.currentUser;
		
		try {
		  const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/roomListPublic', {
		    method: 'GET',
		    headers: {
		      'Content-Type': 'application/json'
		    },
		  });
		  
		  const result = await response.json();
		  console.log(result);
		  if (result.code === 200) { // 假设后端返回code为200时表示登录成功
		    this.group=result.data;
			this.newgroups=this.group.map(group => ({
		      ...group,
		      title: group.name,
		      imageUrl: group.bgImage,
			  subtitle: group.bio,
		    })); 
			console.log(this.group);
		  } else {
		    // 将后端返回的错误信息设置到 errorText 中
		    this.errorVisible = true;
		    this.errorText = result.msg;
		    throw new Error(this.errorText);
		  }
		} catch (error) {
		  this.errorVisible = true;
		  this.errorText = error.message;
		  // 可以在这里添加更多的错误处理逻辑
		}
	  },
	  methods: {
	    
	  }
	}
</script>

<style>
	scroll-view{
		margin-bottom: 60px;
		background-color: #f0f0f0;
	}
	.slider{
		display: flex; /* 使用 flex 布局 */
	    justify-content: center; /* 水平居中 */
		background-color: white;
	}
	.sliderBox {
	  width: 90vw; /* 设置宽度为视口宽度的100% */
	  height: 25vh; /* 设置高度为视口高度的40% */
	  
	}
	swiper-item{
		background-color: blue;
	}
	.slider-image{
		display: block; /* 确保图片是块级元素 */
		margin: 0 auto; /* 图片居中 */
		width: 100%; /* 高度充满整个 swiper-item */
	}
	
	.content {
	  padding: 30rpx;
	  box-sizing: border-box;
	  column-count: 2;
	}
	image {
	  width: 100%;
	  border-radius: 6rpx;
	}
	.table-container {
	  width: 100%;
	  margin-top: 20rpx;
	  margin-bottom: 60px;
	}
	.alert-box {
	  width: 650rpx;
	  height: 150rpx;
	  margin-bottom: 60rpx;
	  padding: 0rpx 20rpx;
	  font-size: 34rpx;
	  line-height: 48rpx;
	  display: flex;
	  align-content: center;
	  overflow: hidden;
	  color: #EE593C;
	  align-items: center;
	}
</style>