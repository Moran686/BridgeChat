<template>
  <view class="login">
    <view class="title">Bridge登录</view>
    <view class="password-box">
      <input v-model="email" class="password-input" placeholder="请输入邮箱" />
    </view>
    <view class="password-box">
      <input v-model="password" class="password-input" placeholder="请输入密码":type="passwordVisible ? 'text' : 'password'">
      <image class="password-image" @click="switchPasswordVisible" src="/static/images/visible.png"></image>
    </view>
    <view v-show="errorVisible" class="alert-box">
      <view>{{ errorText }}</view>
    </view>
    <button class="login-btn" @click="login">登录</button>
    <view class="version">{{ versionName }}</view>
	<view class="register-prompt">
		  没有注册？<text @click="goToRegister" class="register-link">点击注册</text>
	</view>
  </view>
</template>

<script>
  const { versionName } = require('../manifest.json');

  export default {
    name: 'Login',
    data() {
      return {
        versionName: versionName,
        email: '',
        password: '',
		passwordVisible: false,
        errorVisible: false,
        errorText: '',
      };
    },
    methods: {
      switchPasswordVisible() {
        this.passwordVisible = !this.passwordVisible;
      },
      async login() {
        if (!this.email || !this.password) {
          this.errorVisible = true;
          this.errorText = '邮箱和密码不能为空';
          return;
        }
        try {
            const response = await fetch('http://120.46.94.52:5200/api/v1/user/login', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              email: this.email,
              password: this.password
            })
          });
		  
          const result = await response.json();
		  console.log(result)
          if (result.code === 200) { // 假设后端返回code为200时表示登录成功
		  const userData = {
		      ...result.data,
		      name: result.data.username // 将 username 重命名为 name
		    };
		    // 删除原始的 username 属性（如果需要）
		    delete userData.username;
		    // 将修改后的数据保存到本地存储
			console.log(userData);
		    uni.setStorageSync('currentUser', userData);
			uni.setStorageSync('Authorization','Bearer '+userData.token);
            uni.switchTab({ url: './conversations' });
          } else {
            // 将后端返回的错误信息设置到 errorText 中
			this.errorVisible = true;
            this.errorText = result.msg;
            throw new Error(this.errorText);
          }
        } catch (error) {
          this.errorVisible = true;
          this.errorText = error.message;
        }
      },
	  goToRegister() {
	  	    // 使用 Uni-app 的页面跳转方法
	  	    uni.navigateTo({ url: '/pages/register'});
	  }
    }
  };
</script>

<style>
  .login {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .title {
    padding-top: 160rpx;
    height: 100rpx;
    font-size: 60rpx;
    text-align: center;
    font-family: Source Han Sans CN;
    font-style: normal;
    font-weight: normal;
    color: #d02129;
    margin-bottom: 80rpx;
  }

  .alert-box {
    width: 650rpx;
    height: 150rpx;
    margin-bottom: 60rpx;
    padding: 0rpx 20rpx;
    font-size: 34rpx;
    line-height: 48rpx;
    display: flex;
    align-content: center;
    overflow: hidden;
    color: #EE593C;
    align-items: center;
  }

  .alert-box image {
    width: 30rpx;
    height: 30rpx;
    margin-right: 20rpx;
  }

  .login-btn {
    width: 680rpx;
    height: 100rpx;
    line-height: 100rpx;
    font-size: 36rpx;
    text-align: center;
    color: #ffffff;
    background: #d02129;
    outline: none;
    border: 0;
  }
  .login-btn:hover{
	  background-color: #b0302e;
  }

  .password-box {
    position: relative;
	
  }

  .password-input {
    width: 620rpx;
    padding: 28rpx;
    border: 1px solid #cccccc;
    margin-bottom: 40rpx;
    font-size: 34rpx;
	border-radius: 5px;
  }

  .password-image {
    width: 50rpx;
    height: 50rpx;
    position: absolute;
    top: 28rpx;
    right: 28rpx;
  }

  .version {
    color: #ffffff;
    font-size: 40rpx;
    margin-top: 60rpx;
  }

  view {
    user-select: text;
  }
  .register-prompt {
    margin-top: 10px;
    font-size: 14px;
  }
  
  .register-link {
    color: #4CAF50;
    cursor: pointer;
  }
</style>
