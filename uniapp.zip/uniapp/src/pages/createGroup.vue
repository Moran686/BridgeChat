<template>
	<view class="create">
	  <view class="avatar"><image src="/static/images/group.png"></image></view>
	    <view>
		  <view>
			<text>名称*：</text>
			<input v-model="name" class="input-name" placeholder="请输入名称" >
		  </view>
		  <view>
			<text>简介：</text>
			<textarea v-model="bio" class="input-bio" placeholder="说点什么吧" ></textarea>
		  </view>
		  <view>
		  	<text>类型：</text>
		  	<view class="photo-view">
		  	    <view class="photo-item" v-for="(photo, index) in photos" :key="index" @click="toggleZoom(index, photo)">
		  	        <image :src="photo" :class="{'photo-image': true, 'zoomed': isZoomed(index)}"></image>
		  	    </view>
		  	</view>
		  </view>
			<!--    错误提示信息-->
		  <view v-show="errorVisible" class="alert-box">
			<span>{{ errorText }}</span>
		  </view>
		</view>  
	  <!-- 注册按钮 -->
	  <button class="create-btn" @click="create">创建</button>
	
	</view>
</template>

<script>
export default {
	data() {
	  return {
		creator:null,
	    email:null,
	    errorVisible: false,
	    errorText: '',
	    versionName: 'v1.0.0',
		photos: [
		    '/static/images/game.jpg',
		    '/static/images/love.jpg',
		    '/static/images/learn.jpg',
		],
		zoomedIndex: -1, // 当前放大的图片索引，-1表示没有图片被放大
		bgImage: '', // 存储当前放大的图片路径
		name:'',
		bio:'',
		avatar:'/static/images/group.png',
	  };
	},
	onShow() {
		let currentUser = uni.getStorageSync('currentUser');
		let Authorization=uni.getStorageSync('Authorization');
		console.log(currentUser);
		console.log(Authorization);
		this.creator=currentUser;
	},
	methods:{
		toggleZoom(index, photoPath) {
		      this.zoomedIndex = this.zoomedIndex === index ? -1 : index;
		      if (this.zoomedIndex === index) {
		        this.bgImage = photoPath; // 更新当前放大的图片路径
		      } else {
		        this.bgImage = ''; // 清空当前放大的图片路径
		      }
		},
		isZoomed(index) {
		      return this.zoomedIndex === index; // 返回当前图片是否被放大
		},
		async create() {
		      if (this.bgImage) {
		        // 这里可以进行提交操作，例如发送到服务器或打印到控制台
		        console.log('提交的图片路径:', this.bgImage);
				console.log('名称:', this.name);
				console.log('简介:', this.bio);
		        // 清空放大的图片路径
		        this.zoomedIndex = -1;
				try {
			      const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/createRoom', {
			      method: 'POST',
			      headers: {
					'Content-Type': 'application/json',
			        Authorization: uni.getStorageSync('Authorization')
			      },
			      body: JSON.stringify({
			        name: this.name,
					type:'group',
			        avatar: this.avatar,
					bio: this.bio || '作者很懒，什么都没有留下',
					bgImage:this.bgImage,
			      })
			    });
			    
			    const result = await response.json();
			    console.log(result)
			    if (result.code === 200) { 
					//跳转聊天
					uni.navigateTo({
					  url: './groupChat?to=' + result.data.id
					});
			    } else {
			      // 将后端返回的错误信息设置到 errorText 中
			  	this.errorVisible = true;
			      this.errorText = result.msg;
			      throw new Error(this.errorText);
			    }
			  } catch (error) {
			    this.errorVisible = true;
			    this.errorText = error.message;
			  }
		      } else {
		        // 提示用户选择图片
		        uni.showToast({
		          title: '请先选择一个类型',
		          icon: 'none'
		        });
		      }
			  
		},
	},
};
</script>

<style>
	.create {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	.avatar {
	  width: 150rpx;
	  height: 150rpx;
	  margin: 20rpx;
	  overflow: hidden;
	  position: relative;
	  border-radius: 150rpx;
	}
	
	.avatar image {
	  width: 100%;
	  height: 100%;
	  display: block;
	}
	.create-btn {
	  width: 500rpx;
	  height: 90rpx;
	  line-height: 100rpx;
	  font-size: 36rpx;
	  text-align: center;
	  color: #ffffff;
	  background: #d02129;
	  outline: none;
	  border: 0;
	  margin-top: 10%;
	}
	text{
		line-height: 60rpx;
	}
	.input-name {
	  width: 500rpx;
	  padding: 20rpx;
	  border: 1rpx solid #cccccc;
	  margin-bottom: 20rpx;
	  font-size: 30rpx;
	  border-radius: 5px;
	}
	.input-bio {
	  width: 500rpx;
	  height: 200rpx;
	  padding: 20rpx;
	  border: 1rpx solid #cccccc;
	  margin-bottom: 20rpx;
	  font-size: 30rpx;
	  border-radius: 5px;
	}
	.photo-view {
	  overflow-x:  scroll;
	  border: 1rpx solid #cccccc;
	  border-radius: 5px;
	}
	.photo-item {
	  display: inline-block;
	  margin:15rpx;
	  width: 150rpx;
	  height: 100rpx;
	}
	.photo-image {
	  width: 100%;
	  height: 100%;
	}
	.photo-image.zoomed {
	  transform: scale(1.1); /* 放大2倍 */
	  border: 1rpx solid #000000; /* 显示边框 */
	  z-index: 10; /* 确保放大的图片在最上层 */
	  position: relative; /* 相对定位，以便显示边框和阴影 */
	}
	.alert-box {
	  width: 500rpx;
	  height: 150rpx;
	  margin-bottom: 60rpx;
	  padding: 0rpx 20rpx;
	  font-size: 34rpx;
	  line-height: 48rpx;
	  display: flex;
	  align-content: center;
	  overflow: hidden;
	  color: #EE593C;
	  align-items: center;
	}
</style>