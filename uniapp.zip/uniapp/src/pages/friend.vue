<template>
	<div class="friend">
	  <div class="top">
	    <image :src="friend.avatar"></image>
	    <view class="name">{{ friend.name }}</view>
	  </div>
	  
	  <div class="bottom">
	    <view class="subtitle">
			<view>邮箱：{{friend.email}}</view>
			<view>性别：{{friend.gender}}</view>
			<view>生日：{{friend.birthday}}</view>
			<view>介绍：</view>
			<view class="sub">{{friend.bio}}</view>
		</view>
		<!--    错误提示信息-->
		<view v-show="errorVisible" class="alert-box">
			<span>{{ errorText }}</span>
		</view>
	    <view class="subscribe" @click="friendChat">发信息</view>
	  </div>
	</div>
</template>

<script>
	import restApi from '../lib/restapi';
	export default {
	  name: 'friend',
	  data() {
	    return {
	      friend: null,
		  id:null,
		  errorVisible: false,
		  errorText: '',
	    }
	  },
	  onLoad(options) {
	      // options参数包含了页面跳转时传递的参数
	      const id = options.to; // 从options中读取id
		  this.id=id;
	      console.log('Friend ID:', id);
	  },
	  async onShow() {
	    let currentUser = getApp().globalData.currentUser;
	    try {
	    	const response = await fetch(`http://120.46.94.52:5200/api/v1/user/getDetailAll?id=${encodeURIComponent(this.id)}`, {
	    		method: 'GET',
	    		headers: {
	    			'Content-Type': 'application/json',
					Authorization: uni.getStorageSync('Authorization')
	    		},
	    	});
	    	const result = await response.json();
	    	console.log(result);
	    	if (result.code === 200) { 
				this.friend=result.data;
				this.friend= {
				  ...result.data,
				  name: result.data.username
				};
	    	} else {
	    		this.errorVisible = true;
	    		this.errorText = result.msg;
	    		throw new Error(this.errorText);
	    	}
	    } catch (error) {
	    	this.errorVisible = true;
	    	this.errorText = error.message;
	    };
	  },
	  methods: {
	    friendChat () {
		  //加入社区
		  //跳转聊天
	      uni.navigateTo({
	        url: './privateChat?to=' + this.id
	      });
	    },
	  }
	}
</script>
	
<style>
	.friend {
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	.top {
	  height: 30%;
	  width: 100%;
	  background-color: #e6e6e6;
	  display: flex;
	  position: relative;
	  flex-direction: column;
	  justify-content: center;
	  align-items: center;
	  
	}
	
	.top image {
	  width: 156rpx;
	  height: 156rpx;
	  border-radius: 156rpx;
	}
	
	.top .name {
	  margin-top: 20rpx;
	  padding:10rpx;
	  font-size: 15px;
	  font-weight: bold;
	  border-radius: 10rpx;
	}
	
	.bottom {
	  display: flex;
	  flex-direction: column;
	  line-height: 50rpx;
	}
	
	.subtitle {
	  height: 70%;
	  margin: 10%;
	  display: block; /* 确保.subtitle表现为块级元素 */
	}
	
	.subtitle view {
	  display: block; /* 使每个.text元素占据一行 */
	  line-height: 1.5;
	}
	.sub{
		max-height: 60%;
		padding: 5%;
		overflow: hidden;  /* 隐藏溢出的水平内容 */
		overflow-y: auto; /* 当内容超出时显示垂直滚动条 */
		border-radius: 20rpx;
		border: 5rpx solid #e6e6e6;
	}
	.subscribe {
	  text-align: center;
	  width: 40%;
	  height: 76rpx;
	  line-height: 76rpx;
	  margin: 0 auto;
	  background-color: #d02129;
	  border-radius: 10rpx;
	  color: #FFFFFF;
	  font-size: 34rpx;
	  position: absolute;
	  bottom: 10%;
	  left: 30%;
	}
	.alert-box {
	  width: 500rpx;
	  height: 150rpx;
	  margin-bottom: 60rpx;
	  padding: 0rpx 20rpx;
	  font-size: 34rpx;
	  line-height: 48rpx;
	  display: flex;
	  align-content: center;
	  overflow: hidden;
	  color: #EE593C;
	  align-items: center;
	}
</style>