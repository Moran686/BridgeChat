<template>
  <view class="editGroup">
    <!-- 群头像部分 -->
    <view class="avatar" @click="changeImage('avatar')">
      <image :src="group.avatar" alt="群头像"/>
    </view>
    <!-- 群名称输入框 -->
    <view>
      <view>
        <text>名称*：</text>
        <input v-model="group.name" class="input-name" placeholder="请输入名称" />
      </view>
      <!-- 群简介输入框 -->
      <view>
        <text>简介：</text>
        <textarea v-model="group.bio" class="input-bio" placeholder="说点什么吧"></textarea>
      </view>
      <!-- 背景图选择部分，显示图片 -->
      <view>
        <text>背景图：</text>
        <view class="photo-view" @click="changeImage('bgImage')">
          <image :src="group.bgImage" alt="背景图" class="photo-image" />
        </view>
      </view>
    </view>
    <!-- 错误提示信息 -->
    <view v-show="errorVisible" class="alert-box">
      <span>{{ errorText }}</span>
    </view>
    <!-- 创建按钮 -->
    <button class="submit-btn" @click="saveChanges">保存</button>
  </view>
</template>


<script>
export default {
  name: 'editGroup',
  data() {
    return {
      group: null,
      errorVisible: false,  // 用于控制错误信息的显示
      errorText: ''  ,// 错误提示信息
	  };
  },
  onLoad(options) {
	  this.group = JSON.parse(options.group);
      console.log('this.group:', this.group); // 打印原始 URL 参数
      console.log('Parsed group ID:', this.group.to); // 打印解析后的群组 ID
      const id = this.group.id; // 使用 'to' 作为参数名
  
      //if (!id || isNaN(Number(id)) || Number(id) <= 0) {
        //console.error('Invalid or missing group ID detected:', id); // 记录错误日志
        //this.errorVisible = true;
        //this.errorText = '无效的群组ID';
        //uni.showToast({ title: '无效的群组ID', icon: 'none' });
      //}
      //this.group.id = Number(id);
      this.loadGroupDetails();
    },
  methods: {
	
    async loadGroupDetails() {
      try {
		  
        const response = await uni.request({
          url: `http://120.46.94.52:5200/api/v1/chatRoom/getRoomById?id=${encodeURIComponent(this.group.id)}`,
          method: 'GET',
          data: {
            id: this.group.id.toString() // 确保传递的是字符串类型的 ID
          },
          header: {
            'Content-Type': 'application/json'
          }
        });
		
		// 检查响应是否为有效的 JSON
		if (typeof response[1].data === 'string') {
		  try {
			response[1].data = JSON.parse(response[1].data);
		  } catch (e) {
			console.error('Invalid JSON response:', e);
			throw new Error('服务器返回的数据格式不正确');
		  }
		}
        console.log('Server response:', response); // 打印服务器响应以进行调试

        if (response[1].statusCode === 200 && response[1].data.code === 200) {
			const groupData = response[1].data.data.data;
          this.group = { ...this.group, ...response[1].data.data }; // 更新群组详情
        } else {
          throw new Error(response[1].data.msg || '加载失败');
        }
      } catch (error) {
        console.error('Failed to load group details:', error);
        this.errorVisible = true;
        this.errorText = error.message;
        uni.showToast({ title: '加载群组信息失败，请稍后再试', icon: 'none' });
      }
    },

	async changeImage(imageType) {
	  try {
		const res = await new Promise((resolve, reject) => {
		  uni.chooseImage({
			count: 1,
			sizeType: ['compressed'],
			sourceType: ['album', 'camera'],
			success: (result) => resolve(result),
			fail: (err) => reject(err)
		  });
		});
// 打印返回的完整结果，帮助调试
		console.log("chooseImage result:", res);

		// 检查返回值结构，确认 tempFilePaths 是否有效
		if (res && res.tempFilePaths && res.tempFilePaths.length > 0) {
		  const tempFilePath = res.tempFiles[0].path; // 注意这里使用的是 .path 而不是直接访问 tempFilePaths
		  const uploadResult = await this.uploadGroupImage(tempFilePath);

		  if (uploadResult) {
			// 使用 Vue 的 $set 方法来确保响应式更新
			this.$set(this.group, imageType, uploadResult);
			//uni.setStorageSync('group-options.to', this.group );
			console.log(`${imageType} updated successfully:`, this.group);
			uni.showToast({ title: `${imageType === 'avatar' ? '群头像' : '群背景图'}更新成功`, icon: 'success' });
		  } else {
			uni.showToast({ title: `${imageType === 'avatar' ? '群头像' : '群背景图'}上传失败，请重试`, icon: 'none' });
		  }
		} else {
		  // 如果没有选择图片或者返回结果异常，给出更具体的提示信息
		  if (!res.tempFiles || !Array.isArray(res.tempFiles)) {
			console.error('chooseImage result does not contain valid tempFiles:', res);
			uni.showToast({ title: '选择图片时出错，请稍后再试', icon: 'none' });
		  } else if (res.tempFiles.length === 0) {
			uni.showToast({ title: '未选择图片', icon: 'none' });
		  }
		}
	  } catch (err) {
		// 捕获 chooseImage 的失败情况
		console.error('Failed to choose image:', err);
		if (err.errMsg && err.errMsg.includes('cancel')) {
		  // 用户取消选择图片
		  uni.showToast({ title: '已取消选择图片', icon: 'none' });
		} else {
		  // 其他错误情况
		  uni.showToast({ title: '选择图片时出错，请稍后再试', icon: 'none' });
		}
	  }
	},

	async uploadGroupImage(tempFilePath) {
	  const token = uni.getStorageSync('token');
	  if (!token) {
		uni.showToast({ title: '未登录，请先登录', icon: 'none' });
		return null;
	  }

	  // 验证文件路径是否有效
	  if (!tempFilePath || typeof tempFilePath !== 'string') {
		uni.showToast({ title: '无效的文件路径', icon: 'none' });
		return null;
	  }

	 try {
		return new Promise((resolve, reject) => {
		  uni.uploadFile({
			url: `http://120.46.94.52:5200/api/v1/chatRoom/updateChatRoom/${this.group.id}`,  // 请确保这个 URL 是正确的
			filePath: tempFilePath,
			name: 'file',
			header: {
			  'Authorization': `Bearer ${token}`
			},
			success: (response) => {
			  console.log("Upload response:", response);  // 打印完整的响应
			  try {
				const responseData = JSON.parse(response.data);
				if (responseData.code === 200 && responseData.data && responseData.data.img_url) {
				  console.log('Image URL:', responseData.data.img_url);
				  resolve(responseData.data.img_url);  // 解析并返回图片的 URL
				} else {
				  console.error('Upload failed:', responseData.msg);
				  uni.showToast({ title: '图片上传失败，请稍后再试', icon: 'none' });
				  reject(null);  // 上传失败，返回 null
				}
			  } catch (e) {
				console.error('Invalid JSON response:', e);
				uni.showToast({ title: '服务器返回的数据格式不正确', icon: 'none' });
				reject(null);  // 上传失败，返回 null
			  }
			},
			fail: (err) => {
			  console.error('Upload error:', err);
			  if (err.statusCode === 404) {
				uni.showToast({ title: '上传接口不存在，请检查 API 路径', icon: 'none' });
			  } else {
				uni.showToast({ title: '图片上传时发生错误', icon: 'none' });
			  }
			  reject(null);  // 上传失败，返回 null
			}
		  });
		});
	  } catch (error) {
		console.error('Upload error:', error);
		 console.log('Raw response:', response.data);  // 打印原始响应，帮助调试
		uni.showToast({ title: '图片上传时发生错误', icon: 'none' });
		return null;
	  }
	},

	async updateGroupDetails() {
		  try {

			const response = await uni.request({
			  url: `http://120.46.94.52:5200/api/v1/chatRoom/updateChatRoom/${this.group.id}`, // 包含 id 的完整 URL
			  method: 'PUT',
			  data: {
				bio: this.group.bio,
				type: 'group', // 如果类型固定为 'group'
				name: this.group.name,
			  },
			  header: {
				'Content-Type': 'application/json',
				Authorization: uni.getStorageSync('Authorization')
			  }
			});

			// 检查响应状态码和数据格式
			if (response[1].statusCode === 200 && response[1].data.code === 200) {
			  	uni.navigateTo({
			  	  url: './group?to=' + this.group.id
			  	});
			} else {
			  throw new Error(response[1].data.msg || '更新失败');
			}
		  } catch (error) {
			console.error('Failed to update group details:', error);
			uni.showToast({ title: '更新群组信息失败，请稍后再试', icon: 'none' });
		  }
		},


		async handleImageUpload(tempFilePath, setImageField) {
		  const imageUrl = await this.uploadGroupImage(tempFilePath, setImageField);
		  if (imageUrl) {
			uni.showToast({ title: '图片上传成功', icon: 'success' });
		  }
		},

		uploadAvatar(tempFilePath) {
		  this.handleImageUpload(tempFilePath, (url) => { this.group.avatar = url; });
		},

		uploadBgImage(tempFilePath) {
		  this.handleImageUpload(tempFilePath, (url) => { this.group.bgImage = url; });
		},

		// 定义 saveChanges 方法以避免 Vue 警告
		saveChanges() {
		  this.updateGroupDetails();
		}
	  }
};
</script>


<style >
    .editGroup {
      width: 100%;
  	  height: 100%;
  	  display: flex;
  	  flex-direction: column;
  	  align-items: center;
}
	.avatar {
		  width: 150rpx;
		  height: 150rpx;
		  margin: 20rpx;
		  overflow: hidden;
		  position: relative;
		  border-radius: 150rpx;
	}
    .avatar image {
	  width: 100%;
	  height: 100%;
	  display: block;
	}
	.submit-btn {
	  width: 500rpx;
	  height: 90rpx;
	  line-height: 100rpx;
	  font-size: 36rpx;
	  text-align: center;
	  color: #ffffff;
	  background: #d02129;
	  outline: none;
	  border: 0;
	  position: absolute;
	  bottom: 10%;
	}
	text{
		line-height: 60rpx;
	}
	.input-name {
	  width: 500rpx;
	  padding: 20rpx;
	  border: 1rpx solid #cccccc;
	  margin-bottom: 20rpx;
	  font-size: 30rpx;
	  border-radius: 5px;
	}
	.input-bio {
	  width: 500rpx;
	  height: 200rpx;
	  padding: 20rpx;
	  border: 1rpx solid #cccccc;
	  margin-bottom: 20rpx;
	  font-size: 30rpx;
	  border-radius: 5px;
	}
	.photo-view {
		width: 500rpx;
	}
	.photo-image {
		width: 400rpx;
		height:200rpx;
	}
</style>

