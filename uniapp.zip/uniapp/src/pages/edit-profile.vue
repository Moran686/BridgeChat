<template>
  <view class="edit-profile">
    <form @submit.prevent="saveProfile">
      <!-- 用户ID -->
      <view class="form-item">
        <text class="label">用户ID:</text>
        <input v-model="user.id" disabled class="input-field" />
      </view>
      <!-- 用户名 -->
      <view class="form-item">
        <text class="label">用户名:</text>
        <input v-model="user.name" required class="input-field" />
      </view>
      <!-- 邮箱 -->
      <view class="form-item">
        <text class="label">邮箱:</text>
        <input v-model="user.email" type="email" required class="input-field" />
      </view>
      <!-- 生日 -->
      <view class="form-item">
        <text class="label">生日:</text>
        <picker mode="date" @change="bindDateChange" :value="user.birthday">
          <view class="input-field">{{ user.birthday || '请选择日期' }}</view>
        </picker>
      </view>
      <!-- 性别 -->
      <view class="form-item">
        <text class="label">性别:</text>
        <picker @change="bindGenderChange" :value="genderIndex" :range="genders">
          <view class="input-field">{{ genders[genderIndex] }}</view>
        </picker>
      </view>
      <!-- 个性签名 -->
      <view class="form-item">
        <text class="label">个人介绍:</text>
        <textarea v-model="user.bio" placeholder="请输入个人介绍"  class="input-bio"></textarea>

      </view>
      <!-- 提交按钮 -->
      <button formType="submit" class="submit-btn">保存</button>
    </form>
  </view>
</template>

<script>
export default {
  data() {
    return {
      user: {
        id: '',
        name: '',
        email: '',
        birthday: '',
        gender: '',
        bio: ''
      },
      genders: ['女', '男', '保密'],
      genderIndex: 0, // 默认选择第一个选项
    };
  },
  onLoad() {
    const currentUser = uni.getStorageSync('currentUser');
    const token = uni.getStorageSync('Authorization');
    if (currentUser && token) {
      this.user = { ...this.user, ...currentUser };
      this.genderIndex = this.genders.indexOf(this.user.gender);
      // 如果性别字段不匹配，则默认选择第一个
      if (this.genderIndex === -1) {
        this.genderIndex = 0;
      }
    } else {
      uni.showToast({ title: '用户信息或token丢失，请重新登录', icon: 'none' });
    }
  },
  methods: {
    // 处理性别选择变化
    bindGenderChange(e) {
      this.genderIndex = e.detail.value;
      this.user.gender = this.genders[this.genderIndex];
    },

    // 处理生日选择变化
    bindDateChange(e) {
      this.user.birthday = e.detail.value;
    },

    // 更新用户资料
    // saveProfile 页面中
    async saveProfile() {
      try {
        const token = uni.getStorageSync('Authorization');
        if (!token) {
          uni.showToast({ title: '未找到有效的身份验证令牌', icon: 'none' });
          return;
        }
    
        const response = await new Promise((resolve, reject) => {
          uni.request({
            url: `http://120.46.94.52:5200/api/v1/user/updateProfile/${this.user.id}`,
            method: 'PUT',
            header: {
              'Content-Type': 'application/json',
              Authorization: uni.getStorageSync('Authorization')
            },
            data: { bio: this.user.bio },
            success(res) {
              resolve(res);
            },
            fail(err) {
              reject(err);
            }
          });
        });
    
        if (response.statusCode === 200 && response.data.code === 200) {
    
          // 更新缓存数据
          uni.setStorageSync('currentUser', this.user);
    
          // 发出刷新事件通知 mine.vue 页面
          uni.$emit('refreshUserData', this.user);  // 发送一个事件通知
    
          // 跳转到 mine.vue 页面
          uni.switchTab({ url: './mine' });
        } else {
          uni.showToast({ title: '保存失败，请重试', icon: 'none' });
        }
      } catch (error) {
        console.error('请求错误:', error);
        uni.showToast({ title: '请求失败，请重试', icon: 'none' });
      }
    }
  }
};
</script>



<style scoped>
.edit-profile {
  width: 100%;
  	  height: 100%;
  	  display: flex;
  	  flex-direction: column;
  	  align-items: center;
}

.form-item {
  display: flex;
  flex-direction: column;
  margin-bottom: 8px;
}

.label {
	margin-top: 10rpx;
  line-height: 40rpx;
}

.input-field {
  width: 500rpx;
  	  padding: 15rpx;
  	  border: 1rpx solid #cccccc;
  	  font-size: 30rpx;
  	  border-radius: 5px;
}
.input-bio {
	  width: 500rpx;
	  height: 200rpx;
	  padding: 10rpx;
	  border: 1rpx solid #cccccc;
	  font-size: 30rpx;
	  border-radius: 5px;
	}
.submit-btn {
  width: 500rpx;
  	  height: 90rpx;
  	  line-height: 100rpx;
  	  font-size: 36rpx;
  	  text-align: center;
  	  color: #ffffff;
  	  background: #d02129;
  	  outline: none;
  	  border: 0;
	  margin-top: 20%;
}

</style>