<template>
  <div class="contacts">
    <div class="contacts-container">
      <view class="add-title">
		  <image class="add-icon" src="/static/images/add.png" @click="showAction"/>
	  </view>
	  <view class="action-container" v-if="actionVisible">
		<view class="layer" @click="actionVisible = false"></view>
	    <view class="action-box">
		    <view class="action-item" @click="showAddContact">
				<image class="icon" src="/static/images/add-friends.png"></image>添加用户/社区
			</view>
		    <view class="action-item" @click="showCreateGroup">
				<image class="icon" src="/static/images/add-group.png"></image>创建社区
			</view>
		</view>
	  </view>
	  <view class="contacts-title" v-if="groups && groups.length !==0">社区</view>
      <div class="user-list">
        <div class="user-list-item" v-for="(group, id) in groups" :key="id" >
          <div class="user-item-avatar" @click="groupDetail(group.id)">
            <image :src="group.avatar"/>
          </div>
          <div class="user-item-info" @click="groupChat(group)">
            <span class="user-item-info__name">{{ group.name }}</span>
          </div>
        </div>
      </div>
      <view class="contacts-title" v-if="friends !==null">联系人</view>
      <div class="user-list">
        <div class="user-list-item">
          <div class="user-item-avatar" @click="friendDetail(friends.id)">
            <image :src="friends.avatar"></image>
          </div>
          <div class="user-item-info" @click="privateChat(friends)">
            <span class="user-item-info__name">{{ friends.name }}</span>
          </div>
        </div>
      </div>
    </div>
	
  </div>
</template>

<script>
  import restApi from '../lib/restapi';

  export default {
    name: 'contacts',
    data() {
      return {
        friends:null,
        groups: [],
		actionVisible:false
      }
    },
    async onShow() {
      let currentUser = getApp().globalData.currentUser;
	  let id=0;
	  if(currentUser.id===1){
		  id=4;
	  }
	  if(currentUser.id===4){
		  id=1;
	  }
	  try {
	  	const response = await fetch(`http://120.46.94.52:5200/api/v1/user/getDetailAll?id=${encodeURIComponent(id)}`, {
	  		method: 'GET',
	  		headers: {
	  			'Content-Type': 'application/json',
	  			Authorization: uni.getStorageSync('Authorization')
	  		},
	  	});
	  	const result = await response.json();
	  	console.log(result);
	  	if (result.code === 200) { 
	  		this.friends= {
	  		  ...result.data,
	  		  name: result.data.username
	  		};
	  	} else {
	  		this.errorVisible = true;
	  		this.errorText = result.msg;
	  		throw new Error(this.errorText);
	  	}
	  } catch (error) {
	  	this.errorVisible = true;
	  	this.errorText = error.message;
	  };
	  try {
	  	const response = await fetch('http://120.46.94.52:5200/api/v1/chatRoom/getUserChatRooms', {
	  		method: 'GET',
	  		headers: {
	  			'Content-Type': 'application/json',
				Authorization: uni.getStorageSync('Authorization')
	  		},
	  	});
	  	      
	  	const result = await response.json();
	  	console.log(result);
	  	if (result.code === 200) { // 假设后端返回code为200时表示登录成功
	  	    this.groups=result.data;
	  	} else {
	  		this.errorVisible = true;
	  		this.errorText = result.msg;
	  		throw new Error(this.errorText);
	  	}
	  } catch (error) {
	  	this.errorVisible = true;
	  	this.errorText = error.message;
	  }
    },
    methods: {
	  showAddContact(){
		uni.navigateTo({
			url: '/pages/addContact'
		})
	  },
	  showCreateGroup(){
		uni.navigateTo({
			url:'/pages/createGroup'
		})
	  },
	  showAction(){
		  this.actionVisible=true
	  },
      privateChat (friend) {
        uni.navigateTo({
          url: './privateChat?to=' + friend.id
        });
      },
      groupChat (group) {
        uni.navigateTo({
          url: './groupChat?to=' + group.id
        });
      },
	  groupDetail(id){
	  	uni.navigateTo({
	  	  url: './group?to=' + id
	  	});
	  },
	  friendDetail(id){
		uni.navigateTo({
		  url: './friend?to=' + id
		});
	  },
    }
  }
</script>

<style>
  .contacts {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  .contacts .contacts-container {
    width: 100%;
    height: 100%;
    overflow: auto;
  }

  .contacts .user-list-item {
    height: 132rpx;
    padding-left: 32rpx;
    display: flex;
    align-items: center;
  }

  .contacts .contacts-title {
    height: 80rpx;
    line-height: 100rpx;
    font-size: 34rpx;
    color: #666666;
    background: #F3F4F7;
    text-indent: 44rpx;
  }

  .contacts .user-list {
    flex-grow: 1;
    background: #ffffff;
    display: flex;
    flex-direction: column;
  }

  .contacts .user-item-avatar {
    width: 96rpx;
    height: 96rpx;
    margin-right: 32rpx;
    overflow: hidden;
    position: relative;
  }

  .contacts .user-item-avatar image {
    width: 100%;
    height: 100%;
    display: block;
  }

  .contacts .user-item-info {
    height: 130rpx;
    padding-right: 32rpx;
    line-height: 88rpx;
    flex-grow: 1;
    border-bottom: 1px solid #EFEFEF;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .contacts .user-item-info__name {
    font-size: 34rpx;
    font-family: Source Han Sans CN;
    font-style: normal;
    font-weight: bold;
    color: #262628;
  }

  .contacts .user-item-info__tips {
    height: 44rpx;
    width: 64rpx;
    border-radius: 24rpx;
    font-size: 34rpx;
    line-height: 44rpx;
    background: #D02129;
    color: #ffffff;
    font-family: Cabin;
    text-align: center;
  }

  .contacts .online-dot {
    position: absolute;
    width: 32rpx !important;
    height: 32rpx !important;
    right: 0;
    bottom: 0;
  }
  .add-icon {
      right: 20rpx;
      width: 60rpx;
      height: 60rpx;
      position: fixed;
      top: 120rpx;
      z-index: 2;
  }
  .action-container {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
	display: flex;
  }
  
  .action-container .layer {
    position: absolute;
    top: 0;
    left: 0;
	background: rgba(51, 51, 51, 0.1);
    width: 100%;
    height: 100%;
    z-index: 99;
  }
  .action-box {
    width: 250rpx;
    height: 140rpx;
    background: #ffffff;
    position: fixed;
	top: 150rpx;
	left: auto;
	right: 50rpx;
    z-index: 100;
	border: 1px solid #cecece;
    border-radius: 10rpx;
    overflow: hidden;
  }
  
  .action-item {
    line-height: 70rpx;
    font-size: 28rpx;
    color: #262628;
    border-bottom: 1px solid #EFEFEF;
	display: flex;
	align-items: center;
  }
  .action-item .icon{
	  width: 30rpx;
	  height: 30rpx;
	  margin-right: 5rpx;
	  margin-left: 15rpx;
  }
</style>
