<template>
  <view class="register">
    <view class="title">Bridge注册</view>
	<!-- 邮箱输入框 -->
    <view class="email-box">
      <input v-model="email.value" class="input-field" placeholder="请输入邮箱" >
    </view>
    <!-- 密码输入框 -->
    <view class="password-box">
      <input v-model="password1.value" class="input-field" placeholder="请输入密码" :type="password1.visible ? 'text' : 'password'">
      <image class="password-image" @click="switchPasswordVisible" src="/static/images/visible.png"></image>
    </view>
    <!-- 确认密码输入框 -->
    <view class="confirm-password-box">
      <input v-model="password2.value" class="input-field" placeholder="请再次输入密码" :type="password2.visible ? 'text' : 'password'">
      <image class="password-image" @click="switchConfirmPasswordVisible" src="/static/images/visible.png"></image>
    </view>
    <!-- 用户名输入框 -->
    <view class="input-box">
      <input v-model="username.value" class="input-field" placeholder="请输入用户名" type="text">
    </view>
	<!--    错误提示信息-->
    <view v-show="errorVisible" class="alert-box">
      <image src="/static/images/alert-icon.png"></image>
      <span>{{ errorText }}</span>
    </view>
    <!-- 注册按钮 -->
    <button class="register-btn" @click="register">注册</button>
    <!-- 登录提示 -->
    <view class="login-prompt">
      已经注册？<text @click="goToLogin" class="login-link">点击登录</text>
    </view>

  </view>
</template>

<script>
export default {
  data() {
    return {
      email: {
        value: '',
        valid: null // 用于标记邮箱是否有效
      },
      password1: {
        value: '',
        visible: false
      },
      password2: {
        value: '',
        visible: false
      },
      username: {
        value: ''
      },
      errorVisible: false,
      errorText: '',
      versionName: 'v1.0.0'
    };
  },
  methods: {
    switchPasswordVisible() {
      this.password1.visible = !this.password1.visible;
    },
    switchConfirmPasswordVisible() {
      this.password2.visible = !this.password2.visible;
    },
    async register() {
      // 基本验证逻辑
      if (!this.email.value || !this.password1.value || !this.password2.value || !this.username.value) {
        this.errorVisible = true;
        this.errorText = '所有字段不能为空';
        return;
      }

      if (this.password1.value !== this.password2.value) {
        this.errorVisible = true;
        this.errorText = '两次输入的密码不一致';
        return;
      }
      try {
          const response = await fetch('http://120.46.94.52:5200/api/v1/user/register', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              email: this.email.value,
              password1: this.password1.value,
              password2: this.password2.value,
              username: this.username.value
            })
          });
		  
          const result = await response.json();
		  console.log(result)
          if (result.code==200) { // 假设后端返回code为200时表示登录成功
            uni.showToast({ title: '注册成功', icon: 'success' });
            this.goToLogin(); // 注册成功后跳转到登录页面
          } else {
            // 将后端返回的错误信息设置到 errorText 中
			this.errorVisible = true;
            this.errorText = result.msg|| '注册失败，请重试';
            throw new Error(this.errorText);
          }
        } catch (error) {
          this.errorVisible = true;
          this.errorText = error.message;
        }
    },
    goToLogin() {
      // 使用 Uni-app 的页面跳转方法
      uni.navigateTo({ url: '/pages/login'});
    }
  }
};
</script>

<style scoped>
.register {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.title {
  padding-top: 160rpx;
  height: 100rpx;
  font-size: 60rpx;
  text-align: center;
  font-style: normal;
  font-weight: normal;
  color: #d02129;
  margin-bottom: 80rpx;
}

.email-box, .password-box, .confirm-password-box, .input-box {
  position: relative; /* 确保父级是相对定位 */
}

  .input-field {
    width: 560rpx;
    padding: 20rpx;
    border: 1px solid #cccccc;
    margin-bottom: 20rpx;
    font-size: 30rpx;
  }

.password-image {
  width: 50rpx;
  height: 50rpx;
  position: absolute;
  top: 50%;
  right: 28rpx;
  transform: translateY(-50%); /* 竖直居中 */
  cursor: pointer;
}

.alert-box {
  width: 640rpx;
  height: 60rpx;
  margin-bottom: 60rpx;
  padding: 0rpx 20rpx;
  font-size: 34rpx;
  line-height: 48rpx;
  display: flex;
  align-content: center;
  overflow: hidden;
  color: #EE593C;
  align-items: center;
}

.alert-box image {
  width: 30rpx;
  height: 30rpx;
  margin-right: 20rpx;
}

.register-btn {
  width: 600rpx;
  height: 90rpx;
  line-height: 100rpx;
  font-size: 36rpx;
  text-align: center;
  color: #ffffff;
  background: #d02129;
  outline: none;
  border: 0;
}

.login-prompt {
  margin-top: 10px;
  font-size: 14px;
}

.login-link {
  color: #4CAF50;
  cursor: pointer;
}

.version {
  color: #ffffff;
  font-size: 40rpx;
  margin-top: 60rpx;
}
</style>